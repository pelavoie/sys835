function snr = calcul_snr(Vn2, noise)
  % Calculate SNR from noise and Signal value
  snr = Vn2 / noise;
endfunction
